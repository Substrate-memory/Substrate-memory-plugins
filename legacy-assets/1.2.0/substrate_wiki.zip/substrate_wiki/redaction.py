"""Best-effort credential redaction before session material reaches disk or network."""

from __future__ import annotations

import math
import os
import re
from collections.abc import Mapping, Sequence, Set
from pathlib import Path
from typing import Any

_REDACTED = "[REDACTED]"
_SENSITIVE_KEYS = re.compile(
    r"(?:authorization|proxy-authorization|api[-_]?key|access[-_]?token|refresh[-_]?token|"
    r"password|passwd|secret|cookie|set-cookie|private[-_]?key)",
    re.IGNORECASE,
)
_PATTERNS = (
    re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+"),
    re.compile(r"(?i)\b(api[-_]?key|token|password|secret)\s*[:=]\s*['\"]?[^\s,'\"}]+"),
    re.compile(r"\b(?:sk|pk|ghp|github_pat|xox[baprs])-[-A-Za-z0-9_]{12,}\b"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.DOTALL),
)


def configured_secret_values() -> tuple[str, ...]:
    """Return environment-backed secrets worth replacing by exact value."""
    values: set[str] = set()
    for key, value in os.environ.items():
        if value and len(value) >= 6 and _SENSITIVE_KEYS.search(key):
            values.add(value)
    return tuple(sorted(values, key=len, reverse=True))


def redact_text(value: str, secrets: Sequence[str] | None = None) -> str:
    redacted = value
    for secret in secrets if secrets is not None else configured_secret_values():
        redacted = redacted.replace(secret, _REDACTED)
    for pattern in _PATTERNS:
        redacted = pattern.sub(_REDACTED, redacted)
    return redacted


def redact(value: Any, secrets: Sequence[str] | None = None) -> Any:
    """Return a JSON-safe redacted copy without invoking arbitrary object reprs."""
    secret_values = tuple(secrets) if secrets is not None else configured_secret_values()
    return _redact(value, secret_values, seen=set(), depth=0)


def _redact(value: Any, secrets: Sequence[str], *, seen: set[int], depth: int) -> Any:
    if depth > 32:
        return "[TRUNCATED]"
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else "[NONFINITE]"
    if isinstance(value, str):
        return redact_text(value, secrets)
    if isinstance(value, Path):
        return redact_text(os.fspath(value), secrets)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return "[BINARY]"
    identity = id(value)
    if identity in seen:
        return "[CYCLE]"
    if isinstance(value, Mapping):
        seen.add(identity)
        try:
            result: dict[str, Any] = {}
            for key, child in list(value.items())[:1024]:
                raw_key = key if isinstance(key, str) else f"[{type(key).__name__}]"
                text_key = redact_text(raw_key, secrets)
                if _SENSITIVE_KEYS.search(raw_key):
                    text_key = _REDACTED
                unique_key = text_key
                suffix = 2
                while unique_key in result:
                    unique_key = f"{text_key}#{suffix}"
                    suffix += 1
                result[unique_key] = (
                    _REDACTED
                    if _SENSITIVE_KEYS.search(raw_key)
                    else _redact(child, secrets, seen=seen, depth=depth + 1)
                )
            return result
        finally:
            seen.discard(identity)
    if isinstance(value, Set) and not isinstance(value, (str, bytes, bytearray)):
        seen.add(identity)
        try:
            sanitized = [_redact(child, secrets, seen=seen, depth=depth + 1) for child in list(value)[:1024]]
            return sorted(sanitized, key=lambda child: (type(child).__name__, str(child)[:256]))
        finally:
            seen.discard(identity)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        seen.add(identity)
        try:
            return [_redact(child, secrets, seen=seen, depth=depth + 1) for child in list(value)[:1024]]
        finally:
            seen.discard(identity)
    return f"[UNSUPPORTED:{type(value).__name__}]"
