"""Dedicated history-import worker entry point used by the systemd user unit."""

from __future__ import annotations

import argparse
import os
import subprocess
from pathlib import Path

from .checkpoint import ImportCheckpoint
from .client import SubstrateClient
from .history import HermesHistoryImporter, HermesJSONLHistorySource, HermesSQLiteHistorySource


def checkpoint_path(hermes_home: Path, job_id: str) -> Path:
    if not job_id or not job_id.isalnum() or len(job_id) > 128:
        raise ValueError("invalid job id")
    return hermes_home / "substrate_wiki" / "imports" / "jobs" / job_id / "checkpoint.db"


def run_job(hermes_home: Path, job_id: str) -> dict[str, object]:
    checkpoint = ImportCheckpoint(checkpoint_path(hermes_home, job_id))
    job = checkpoint.job()
    source_kind = str(job["source_kind"])
    locator = Path(str(job["source_locator"]))
    if source_kind == "hermes-sqlite":
        source = HermesSQLiteHistorySource(locator)
    elif source_kind in {"hermes-jsonl", "hermes-official-export"}:
        source = HermesJSONLHistorySource(locator)
    else:
        checkpoint.close()
        raise ValueError("unsupported durable source kind")
    client = SubstrateClient.from_env(timeout=30.0)
    importer = HermesHistoryImporter(
        hermes_home=hermes_home,
        client=client,
        source=source,
        agent_id=str(job["agent_id"]),
    )
    importer.checkpoint = checkpoint
    capabilities = client.capabilities()
    replay = capabilities.get("history_replay")
    if not (
        isinstance(replay, dict)
        and capabilities.get("provider") == "substrate_wiki"
        and 2 in capabilities.get("capture_schema_versions", [])
        and replay.get("protocol") == "stream-v2"
        and replay.get("min_plugin_version") == "1.2.0"
        and replay.get("content_free_completion") is True
        and replay.get("incremental_windows") is True
        and int(replay.get("status_version", 0)) == 2
        and int(capabilities.get("max_event_bytes", 0)) == 262_144
    ):
        checkpoint.set_state("failed", error_class="server_upgrade_required")
        checkpoint.close()
        raise RuntimeError("server_upgrade_required")
    try:
        status = importer.run(wait=True)
        if status.get("complete") and os.name == "posix":
            from .supervisor import unit_instance_name

            subprocess.run(
                ("systemctl", "--user", "disable", unit_instance_name(hermes_home, job_id)),
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        return status
    finally:
        if source_kind == "hermes-official-export":
            try:
                locator.unlink()
            except FileNotFoundError:
                pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hermes-home", type=Path, required=True)
    parser.add_argument("--job-id", required=True)
    args = parser.parse_args(argv)
    try:
        run_job(args.hermes_home.resolve(), args.job_id)
    except Exception:  # noqa: BLE001 - systemd receives only an exit code
        return 1
    return 0


if __name__ == "__main__":
    os.umask(0o077)
    raise SystemExit(main())
